export interface Imagen {
    id: number;
    denominacion: string; // URL de la imagen
}

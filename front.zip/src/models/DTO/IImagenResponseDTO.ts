export interface IImagenResponseDTO {
    id?: number;
    denominacion: string;
}
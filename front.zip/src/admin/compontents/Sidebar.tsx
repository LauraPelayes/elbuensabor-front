export default function SideBar() {
	return (
		<div className="bg-gray-200 rounded-[30px] p-8 min-w-[250px]">
			Sidebar
		</div>
	)
}
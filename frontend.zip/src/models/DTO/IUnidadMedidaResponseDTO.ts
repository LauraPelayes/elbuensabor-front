export interface IUnidadMedidaResponseDTO {
    id?: number;
    denominacion: string;
}
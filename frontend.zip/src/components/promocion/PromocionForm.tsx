import React, { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { crearPromocion } from "../../services/PromocionService";
import { getArticulosManufacturados } from "../../services/ArticuloManufacturadoService";
import "./PromocionForm.css";

const tipos = ["HAPPY_HOUR", "PROMO_1"];

interface ArticuloSeleccionado {
    articuloId: number;
    cantidad: number;
}

interface FormularioPromocion {
    denominacion: string;
    fechaDesde: string;
    fechaHasta: string;
    horaDesde: string;
    horaHasta: string;
    precioPromocional: number;
    tipoPromocion: string;
    articulosSeleccionados: ArticuloSeleccionado[];
}

const PromocionForm: React.FC = () => {
    const { register, handleSubmit, reset, setValue, watch } = useForm<FormularioPromocion>();
    const [articulosDisponibles, setArticulosDisponibles] = useState<any[]>([]);
    const [seleccionados, setSeleccionados] = useState<{ [key: number]: number }>({});

    useEffect(() => {
        getArticulosManufacturados().then(setArticulosDisponibles).catch(console.error);
    }, []);

    const handleCheckboxChange = (articuloId: number, checked: boolean) => {
        if (checked) {
            setSeleccionados(prev => ({ ...prev, [articuloId]: 1 }));
        } else {
            const newSeleccionados = { ...prev };
            delete newSeleccionados[articuloId];
            setSeleccionados(newSeleccionados);
        }
    };

    const handleCantidadChange = (articuloId: number, cantidad: number) => {
        setSeleccionados(prev => ({ ...prev, [articuloId]: cantidad }));
    };

    const onSubmit = async (data: any) => {
        const articulosSeleccionados: ArticuloSeleccionado[] = Object.entries(seleccionados)
            .map(([id, cantidad]) => ({
                articuloId: parseInt(id),
                cantidad: Number(cantidad),
            }))
            .filter(item => item.cantidad > 0);

        try {
            await crearPromocion({ ...data, articulos: articulosSeleccionados });
            alert("¡Promoción creada con éxito!");
            reset();
            setSeleccionados({});
        } catch (error) {
            alert("Error al crear la promoción: " + error);
        }
    };

    return (
        <form onSubmit={handleSubmit(onSubmit)} className="promo-form">
            <h2>Crear Promoción</h2>

            <label>Denominación</label>
            <input type="text" {...register("denominacion")} required />

            <label>Fecha Desde</label>
            <input type="date" {...register("fechaDesde")} required />

            <label>Fecha Hasta</label>
            <input type="date" {...register("fechaHasta")} required />

            <label>Hora Desde</label>
            <input type="time" {...register("horaDesde")} required />

            <label>Hora Hasta</label>
            <input type="time" {...register("horaHasta")} required />

            <label>Precio Promocional</label>
            <input type="number" step="0.01" {...register("precioPromocional")} required />

            <label>Tipo de Promoción</label>
            <select {...register("tipoPromocion")} required>
                <option value="">Seleccione</option>
                {tipos.map((tipo) => (
                    <option key={tipo} value={tipo}>{tipo}</option>
                ))}
            </select>

            <label>Seleccionar Artículos Manufacturados</label>
            {articulosDisponibles.map((art) => (
                <div key={art.id} className="articulo-entry">
                    <input
                        type="checkbox"
                        id={`check-${art.id}`}
                        checked={seleccionados[art.id] !== undefined}
                        onChange={(e) => handleCheckboxChange(art.id, e.target.checked)}
                    />
                    <label htmlFor={`check-${art.id}`}>{art.denominacion}</label>

                    {seleccionados[art.id] !== undefined && (
                        <input
                            type="number"
                            min={1}
                            value={seleccionados[art.id]}
                            onChange={(e) => handleCantidadChange(art.id, Number(e.target.value))}
                            placeholder="Cantidad"
                            style={{ marginLeft: "10px", width: "80px" }}
                        />
                    )}
                </div>
            ))}

            <button type="submit" className="btn-submit">Guardar Promoción</button>
        </form>
    );
};

export default PromocionForm;
